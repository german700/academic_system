import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const DocentesGestion = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    nombre: "",
    correo: "",
    contraseña: "",
    asignatura: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Registrando docente:", formData);
    // Aquí se enviará el formulario al backend
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">Gestionar Docentes</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
        <label className="block mb-2">Nombre:</label>
        <input type="text" name="nombre" value={formData.nombre} onChange={handleChange} className="w-full p-2 border rounded" />

        <label className="block mb-2">Correo:</label>
        <input type="email" name="correo" value={formData.correo} onChange={handleChange} className="w-full p-2 border rounded" />

        <label className="block mb-2">Contraseña:</label>
        <input type="password" name="contraseña" value={formData.contraseña} onChange={handleChange} className="w-full p-2 border rounded" />

        <label className="block mb-2">Asignatura:</label>
        <input type="text" name="asignatura" value={formData.asignatura} onChange={handleChange} className="w-full p-2 border rounded" />

        <button type="submit" className="mt-4 bg-green-500 text-white p-2 rounded hover:bg-green-600">Registrar Docente</button>
      </form>

      <button onClick={() => navigate("/admin")} className="mt-4 text-blue-500 underline">Volver al Dashboard</button>
    </div>
  );
};

export default DocentesGestion;