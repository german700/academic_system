import React from "react";

const CursosGestion = () => {
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">Gestión de Cursos</h1>
      {/* Aquí irá el formulario de registro y la lista de cursos */}
    </div>
  );
};

export default CursosGestion;