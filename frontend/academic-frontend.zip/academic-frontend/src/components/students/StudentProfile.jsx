// /frontend/academic-frontend/src/components/students/StudentProfile.jsx
import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { UserCircle } from 'lucide-react';
import { studentService } from '../../services/student.service';

const StudentProfile = ({ studentId }) => {
  const [student, setStudent] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const studentData = await studentService.getStudent(studentId);
        const analysisData = await studentService.getStudentAnalysis(studentId);
        
        setStudent(studentData);
        setAnalysis(analysisData);
      } catch (err) {
        setError('Error al cargar los datos del estudiante');
        console.error('Error:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [studentId]);

  if (loading) return <div className="flex justify-center p-8">Cargando...</div>;
  if (error) return <div className="text-red-500 p-4">{error}</div>;
  if (!student || !analysis) return null;

  // Datos para la gráfica comparativa
  const compareData = [
    {
      period: 'Q1',
      estudiante: analysis.comparative_analysis.student_average,
      promedio: analysis.comparative_analysis.class_average,
    },
    // Añadir más periodos según los datos disponibles
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Perfil básico */}
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <div className="flex items-center space-x-4">
          {student.photo ? (
            <img 
              src={student.photo} 
              alt={student.name} 
              className="h-24 w-24 rounded-full object-cover"
            />
          ) : (
            <UserCircle className="h-24 w-24 text-gray-300" />
          )}
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{student.name}</h2>
            <p className="text-gray-500">ID: {student.student_id}</p>
            <p className="text-gray-500">Grado: {student.grade_level}</p>
          </div>
        </div>
      </div>

      {/* Análisis académico */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Análisis de Desempeño</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-700">Fortalezas:</h4>
              <ul className="list-disc pl-5 text-gray-600">
                {analysis.strengths.map((strength, index) => (
                  <li key={index}>{strength}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-700">Áreas de Mejora:</h4>
              <ul className="list-disc pl-5 text-gray-600">
                {analysis.areas_for_improvement.map((area, index) => (
                  <li key={index}>{area}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-700">Patrón de Aprendizaje:</h4>
              <p className="text-gray-600">
                Consistencia: {analysis.learning_patterns.consistency}
              </p>
            </div>
          </div>
        </div>

        {/* Gráfica comparativa */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Comparativa de Rendimiento</h3>
          <LineChart width={500} height={300} data={compareData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="period" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="estudiante" 
              stroke="#2563eb" 
              name="Estudiante"
            />
            <Line 
              type="monotone" 
              dataKey="promedio" 
              stroke="#9ca3af" 
              name="Promedio del Curso"
            />
          </LineChart>
        </div>
      </div>
    </div>
  );
};

export default StudentProfile;