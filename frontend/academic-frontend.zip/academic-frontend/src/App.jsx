// frontend/academic-frontend/src/App.jsx
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.jsx';
import Login from './components/auth/Login.jsx';
import StudentProfile from './components/students/StudentProfile.jsx';
import PrivateRoute from './components/shared/PrivateRoute.jsx';
import DirectivoDashboard from './components/admin/DirectivoDashboard';
import EstudiantesGestion from "./components/admin/EstudiantesGestion";
import DocentesGestion from "./components/admin/DocentesGestion";
import AdministrativosGestion from "./components/admin/AdministrativosGestion";
import CursosGestion from "./components/admin/CursosGestion";

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/Directivo-dashboard" element={<DirectivoDashboard />} />
          <Route path="/admin/estudiantes" element={<EstudiantesGestion />} />
          <Route path="/admin/docentes" element={<DocentesGestion />} />
          <Route path="/admin/administrativos" element={<AdministrativosGestion />} />
          <Route path="/admin/cursos" element={<CursosGestion />} />
          <Route
            path="/student/:id"
            element={
              <PrivateRoute>
                <StudentProfile />
              </PrivateRoute>
            }
          />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;